Much simpler readme here:

The .csv files are the downloads I got from the world bank to use as my dataset

The techstack-master folder contains the original project
